document.addEventListener("DOMContentLoaded", function () {
  const name1Input = document.getElementById("name1");
  const name2Input = document.getElementById("name2");
  const gender1Select = document.getElementById("gender1");
  const gender2Select = document.getElementById("gender2");
  const calculateBtn = document.getElementById("calculateBtn");
  const resetBtn = document.getElementById("resetBtn");
  const swapBtn = document.getElementById("swapDirectionBtn");
  const percentageSpan = document.getElementById("percentage");
  const messageDiv = document.getElementById("message");
  const directionText = document.getElementById("directionText");

  let direction = true; // true: من الأول للثاني

  function updateDirectionText() {
    const g1 = gender1Select.value;
    const g2 = gender2Select.value;
    const fromIcon = direction
      ? g1 === "male"
        ? "👦"
        : "👧"
      : g2 === "male"
      ? "👦"
      : "👧";
    const toIcon = direction
      ? g2 === "male"
        ? "👦"
        : "👧"
      : g1 === "male"
      ? "👦"
      : "👧";
    directionText.textContent = `من ${fromIcon} إلى ${toIcon}`;
  }

  gender1Select.addEventListener("change", updateDirectionText);
  gender2Select.addEventListener("change", updateDirectionText);
  swapBtn.addEventListener("click", function () {
    direction = !direction;
    updateDirectionText();
  });

  function calculateLove(name1, name2) {
    if (!name1 || !name2) return null;
    const combined = name1 + name2;
    let hash = 0;
    for (let i = 0; i < combined.length; i++) {
      hash = (hash << 5) - hash + combined.charCodeAt(i);
      hash |= 0;
    }
    let love = (Math.abs(hash) % 100) + 1;
    if (name1.toLowerCase().trim() === name2.toLowerCase().trim()) {
      love = Math.min(love + 15, 100);
    }
    return love;
  }

  function getLoveMessage(percent, fromName, fromGender, toName, toGender) {
    const fromIcon = fromGender === "male" ? "👦" : "👧";
    const toIcon = toGender === "male" ? "👦" : "👧";
    const fromType = fromGender === "male" ? "الولد" : "البنت";
    const toType = toGender === "male" ? "الولد" : "البنت";

    let base = "";
    if (percent >= 95) base = "💞 حب أسطوري!";
    else if (percent >= 85) base = "❤️ حب أبدي!";
    else if (percent >= 70) base = "💖 حب قوي جداً!";
    else if (percent >= 55) base = "💓 حب جيد";
    else if (percent >= 40) base = "💗 حب متوسط";
    else if (percent >= 25) base = "💔 حب ضعيف";
    else if (percent >= 10) base = "💔 توافق بسيط";
    else base = "💔 لا يوجد حب";

    return `${base} (${fromType} ${fromIcon} ${fromName} → ${toType} ${toIcon} ${toName})`;
  }

  calculateBtn.addEventListener("click", function () {
    const name1 = name1Input.value.trim();
    const name2 = name2Input.value.trim();
    if (!name1 || !name2) {
      alert("الرجاء إدخال الاسمين");
      return;
    }
    const love = calculateLove(name1, name2);
    if (love) {
      percentageSpan.textContent = love + "%";
      const fromName = direction ? name1 : name2;
      const toName = direction ? name2 : name1;
      const fromGender = direction ? gender1Select.value : gender2Select.value;
      const toGender = direction ? gender2Select.value : gender1Select.value;
      messageDiv.textContent = getLoveMessage(
        love,
        fromName,
        fromGender,
        toName,
        toGender
      );
    }
  });

  resetBtn.addEventListener("click", function () {
    name1Input.value = "";
    name2Input.value = "";
    gender1Select.value = "male";
    gender2Select.value = "female";
    direction = true;
    percentageSpan.textContent = "0%";
    messageDiv.textContent = "انتظر الضغط على الزر";
    updateDirectionText();
    name1Input.focus();
  });

  name1Input.addEventListener(
    "keypress",
    (e) => e.key === "Enter" && calculateBtn.click()
  );
  name2Input.addEventListener(
    "keypress",
    (e) => e.key === "Enter" && calculateBtn.click()
  );

  // التهيئة
  updateDirectionText();
});
